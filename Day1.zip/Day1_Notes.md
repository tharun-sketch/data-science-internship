# Day 1 – Environment Setup Notes

## What is Data Science?
Data Science is the practice of extracting useful knowledge and insights from data by
combining programming, statistics, and business/domain understanding. A typical
workflow looks like this:

1. **Collect** raw data (from files, databases, APIs, etc.)
2. **Clean** the data (handle missing values, remove duplicates, fix data types)
3. **Explore & Analyze** the data (summary statistics, patterns, trends)
4. **Visualize** the data (charts and dashboards to make insights easy to understand)
5. **Communicate / Report** findings to support business decisions

For this internship, the project theme is a **Sales Data Analysis Dashboard**, so all
14 days build toward cleaning a sales dataset, analyzing it, visualizing it, and
presenting insights.

## Tools Installed Today
| Tool | Purpose | Verified with |
|------|---------|----------------|
| Python | Programming language for data science | `python --version` |
| VS Code | Code editor (with Python & Jupyter extensions) | Opens & runs `.py` / `.ipynb` files |
| Jupyter Notebook | Interactive notebook environment | `jupyter notebook` launches in browser |
| Git | Version control | `git --version` |
| GitHub | Remote repository hosting | Repo created online |

## GitHub Repository
- Repo name: `sales-data-analysis-dashboard` (suggested)
- Contains: this file, `hello_datascience.py`, and will grow with each day's work

## Outcome
✅ Development environment is fully set up and ready for Day 2 (Python Basics).
