"""
Day 1 - Environment Setup Task
Data Science Internship - Codomax Digital Solutions
"""

def main():
    name = "Your Name"  # TODO: replace with your name
    print("=" * 50)
    print("Hello, Data Science World!")
    print(f"My name is {name}.")
    print("I am starting my Data Science Internship at Codomax Digital Solutions.")
    print("Today I set up my development environment:")
    print("  - Python installed and working")
    print("  - VS Code installed with Python & Jupyter extensions")
    print("  - Jupyter Notebook installed")
    print("  - Git installed and configured")
    print("  - GitHub repository created")
    print("=" * 50)

if __name__ == "__main__":
    main()
